package com.example.chatio_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
